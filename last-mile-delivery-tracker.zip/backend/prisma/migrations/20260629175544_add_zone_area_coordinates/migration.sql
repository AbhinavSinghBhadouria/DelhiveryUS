-- AlterTable
ALTER TABLE "zone_areas" ADD COLUMN     "latitude" DECIMAL(10,7),
ADD COLUMN     "longitude" DECIMAL(10,7);
